﻿## Program Pasjans w Kąsoli
gra stwożona pżez jakuba lazarka

### Odpalenie Programu
Pierwszy sposub ( mincrosoft visual studio jest wymagane)